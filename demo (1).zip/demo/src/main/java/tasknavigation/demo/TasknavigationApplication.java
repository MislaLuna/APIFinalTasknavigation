package tasknavigation.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TasknavigationApplication {

	public static void main(String[] args) {
		SpringApplication.run(TasknavigationApplication.class, args);
	}

}
